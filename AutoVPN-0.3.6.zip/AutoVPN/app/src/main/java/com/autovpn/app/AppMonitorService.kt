package com.autovpn.app

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

/**
 * Monitors the foreground package using incremental UsageEvents queries.
 * The WireGuard tunnel is active only while a selected app is in the foreground.
 */
class AppMonitorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile private var tunnelUp = false
    @Volatile private var lastStatus = ""
    private var activePackages: Set<String> = emptySet()
    private var activeConfigHash: Int? = null
    private var lastConnectAttempt = 0L
    private var foregroundPackage: String? = null
    private var lastEventTime = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        lastStatus = "المراقبة تعمل — بانتظار تطبيق محدد"
        startForeground(NOTIFICATION_ID, notification(lastStatus))
        scope.launch { monitorLoop() }
    }

    private suspend fun monitorLoop() {
        while (scope.isActive) {
            val prefs = getSharedPreferences("autovpn", Context.MODE_PRIVATE)
            // Copy the set: SharedPreferences may return a live cached set.
            val selected = prefs.getStringSet("selected_packages", emptySet()).orEmpty().toSet()
            val config = prefs.getString("wireguard_config", null)

            // Usage access can be revoked from Android Settings while the service
            // is running. Never keep an old foreground-package decision in that case.
            if (!hasUsageAccess()) {
                if (tunnelUp) {
                    val stopped = runCatching {
                        withContext(Dispatchers.IO) { WireGuardController.stop() }
                    }
                    if (stopped.isSuccess) tunnelUp = false
                }
                foregroundPackage = null
                activePackages = emptySet()
                activeConfigHash = null
                updateStatus("تم إيقاف المراقبة: صلاحية إحصائيات الاستخدام غير مفعّلة")
                delay(1500)
                continue
            }

            // UsageEvents can throw if access is revoked between the permission
            // check and the query. Keep the service alive and fail closed in that case.
            val usageRead = runCatching { refreshForegroundPackage() }
            if (usageRead.isFailure) {
                foregroundPackage = null
                if (tunnelUp) {
                    val stopResult = runCatching {
                        withContext(Dispatchers.IO) { WireGuardController.stop() }
                    }
                    if (stopResult.isSuccess) tunnelUp = false
                }
                updateStatus("تعذر قراءة سجل الاستخدام؛ تم إيقاف قرار الاتصال مؤقتاً")
                delay(1500)
                continue
            }
            val shouldConnect = foregroundPackage != null && foregroundPackage in selected
            val selectionChanged = tunnelUp && selected != activePackages
            val configurationChanged = tunnelUp && (config.isNullOrBlank() || config.hashCode() != activeConfigHash)

            if (shouldConnect && (!tunnelUp || selectionChanged || configurationChanged)) {
                if (!config.isNullOrBlank() && System.currentTimeMillis() - lastConnectAttempt >= 5_000L) {
                    lastConnectAttempt = System.currentTimeMillis()
                    updateStatus("جارٍ الاتصال عبر WireGuard…")
                    val result = runCatching {
                        withContext(Dispatchers.IO) {
                            WireGuardController.start(this@AppMonitorService, config, selected)
                        }
                    }
                    if (result.isSuccess) {
                        tunnelUp = true
                        activePackages = selected
                        activeConfigHash = config.hashCode()
                        updateStatus("VPN متصل — ${foregroundPackage ?: "تطبيق محدد"}")
                    } else {
                        tunnelUp = false
                        activePackages = emptySet()
                        activeConfigHash = null
                        updateStatus("فشل الاتصال: ${result.exceptionOrNull()?.localizedMessage ?: "خطأ غير معروف"}")
                    }
                } else if (config.isNullOrBlank()) {
                    updateStatus("أضف ملف إعداد WireGuard أولاً")
                }
            } else if (!shouldConnect && tunnelUp) {
                val result = runCatching { withContext(Dispatchers.IO) { WireGuardController.stop() } }
                if (result.isSuccess) {
                    tunnelUp = false
                    activePackages = emptySet()
                    activeConfigHash = null
                    updateStatus("تم فصل VPN — لا يوجد تطبيق محدد في الواجهة")
                } else {
                    // Keep tunnelUp true so a failed stop is retried on the next pass.
                    updateStatus("تعذر فصل VPN — ستتم إعادة المحاولة")
                }
            } else if (shouldConnect && tunnelUp) {
                updateStatus("VPN متصل — ${foregroundPackage ?: "تطبيق محدد"}")
            } else {
                updateStatus(if (foregroundPackage == null) "بانتظار تطبيق محدد" else "التطبيق الحالي غير محدد")
            }

            delay(750)
        }
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    /**
     * On first run inspect a short recent window to find the current resumed app.
     * Later iterations read only events since the previous query, avoiding a full
     * 24-hour history scan every second.
     */
    private fun refreshForegroundPackage() {
        val manager = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val begin = if (lastEventTime == 0L) now - 30_000L else (lastEventTime - 1_000L).coerceAtLeast(0L)
        val events = manager.queryEvents(begin, now)
        val event = UsageEvents.Event()

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val pkg = event.packageName ?: continue
            val isResume = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }
            val isPause = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_PAUSED ||
                    event.eventType == UsageEvents.Event.ACTIVITY_STOPPED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
            }

            if (isResume) foregroundPackage = pkg
            else if (isPause && foregroundPackage == pkg) foregroundPackage = null
            else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                event.eventType == UsageEvents.Event.KEYGUARD_SHOWN) {
                // Locking the screen must never leave a selected app considered active.
                foregroundPackage = null
            }
        }
        lastEventTime = now
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AutoVPN",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("AutoVPN")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setOngoing(true)
            .build()

    private fun updateStatus(message: String) {
        if (message == lastStatus) return
        lastStatus = message
        getSharedPreferences("autovpn", Context.MODE_PRIVATE).edit().putString("service_status", message).apply()
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.notify(NOTIFICATION_ID, notification(message))
        } else {
            manager.notify(NOTIFICATION_ID, notification(message))
        }
    }

    override fun onDestroy() {
        scope.cancel()
        // Best effort only; Android may terminate the process without this callback.
        runCatching { WireGuardController.stop() }
        getSharedPreferences("autovpn", Context.MODE_PRIVATE).edit().putString("service_status", "المراقبة متوقفة").apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "autovpn_monitor"
        private const val NOTIFICATION_ID = 501
    }
}
