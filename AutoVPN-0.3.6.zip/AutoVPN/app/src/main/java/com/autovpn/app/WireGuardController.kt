package com.autovpn.app

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets

/**
 * Owns the embedded WireGuard backend. Call start/stop from a worker thread:
 * backend.setState() performs blocking VPN/backend work.
 *
 * The supplied .conf must be a real, valid WireGuard configuration. The selected
 * package list is injected as IncludedApplications so only those apps use the tunnel.
 */
object WireGuardController {
    private const val TUNNEL_NAME = "autovpn"

    @Volatile
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = TUNNEL_NAME
        override fun onStateChange(newState: Tunnel.State) = Unit
    }

    @Synchronized
    @Throws(Exception::class)
    fun start(context: Context, wireGuardConfig: String, selectedPackages: Set<String>) {
        require(selectedPackages.isNotEmpty()) { "اختر تطبيقاً واحداً على الأقل" }
        require(!wireGuardConfig.isBlank()) { "ملف إعداد WireGuard فارغ" }

        val appContext = context.applicationContext
        // Fail early for stale/uninstalled package names.
        selectedPackages.forEach { packageName ->
            appContext.packageManager.getApplicationInfo(packageName, 0)
        }

        val scopedConfig = addIncludedApplications(wireGuardConfig, selectedPackages)
        val parsed = Config.parse(
            ByteArrayInputStream(scopedConfig.toByteArray(StandardCharsets.UTF_8))
        )
        // This app promises full-tunnel routing for the chosen apps. Reject a
        // split-tunnel profile instead of silently sending only some destinations.
        val hasDefaultRoute = parsed.peers.any { peer ->
            peer.allowedIps.any { network -> network.mask == 0 }
        }
        require(hasDefaultRoute) {
            "الإعداد لا يحتوي على مسار افتراضي (AllowedIPs = 0.0.0.0/0 أو ::/0)؛ لا يمكن استخدامه كنفق كامل"
        }

        val engine = backend ?: GoBackend(appContext).also { backend = it }
        engine.setState(tunnel, Tunnel.State.UP, parsed)
    }

    @Synchronized
    @Throws(Exception::class)
    fun stop() {
        val engine = backend ?: return
        engine.setState(tunnel, Tunnel.State.DOWN, null)
    }

    private fun addIncludedApplications(config: String, packages: Set<String>): String {
        val packageLine = "IncludedApplications = " + packages.sorted().joinToString(", ")
        val output = StringBuilder()
        var inInterface = false
        var inserted = false

        fun insertPackages() {
            if (inInterface && !inserted) {
                output.append(packageLine).append('\n')
                inserted = true
            }
        }

        config.lineSequence().forEach { originalLine ->
            val line = originalLine.trim()
            if (line.equals("[Interface]", ignoreCase = true)) {
                if (inInterface) insertPackages()
                inInterface = true
                inserted = false
                output.append(originalLine).append('\n')
            } else if (line.equals("[Peer]", ignoreCase = true)) {
                insertPackages()
                inInterface = false
                output.append(originalLine).append('\n')
            } else if (inInterface && (
                    line.startsWith("IncludedApplications", ignoreCase = true) ||
                    line.startsWith("ExcludedApplications", ignoreCase = true)
                )) {
                // Replace any provider-supplied app scope with the user's current selection.
            } else {
                output.append(originalLine).append('\n')
            }
        }
        insertPackages()
        return output.toString()
    }
}
