package com.autovpn.app

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.content.pm.PackageManager
import android.provider.Settings
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("autovpn", Context.MODE_PRIVATE) }
    private var pendingStart = false
    private var usageAccessState by mutableStateOf(false)

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Notification permission is optional for starting a foreground service.
        // Continue either way; Android still exposes the foreground service in system UI.
        startMonitorService()
    }

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && pendingStart) requestNotificationPermissionThenStart()
        pendingStart = false
    }

    private val configPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val config = input.bufferedReader().use { it.readText() }
                    require(config.contains("[Interface]", true) && config.contains("[Peer]", true)) {
                        "الملف لا يبدو كإعداد WireGuard صالح"
                    }
                    // Parse with the actual WireGuard parser before saving, so malformed
                    // keys, endpoints, and unsupported fields are rejected at import time.
                    Config.parse(ByteArrayInputStream(config.toByteArray(StandardCharsets.UTF_8)))
                    val requestedName = queryDisplayName(uri).ifBlank { "WireGuard" }
                    val existing = prefs.getStringSet("profile_names", emptySet()).orEmpty().toMutableSet()
                    var profileName = requestedName.removeSuffix(".conf").ifBlank { "WireGuard" }
                    var suffix = 2
                    while (profileName in existing) {
                        profileName = "${requestedName.removeSuffix(".conf")} ($suffix)"
                        suffix++
                    }
                    existing.add(profileName)
                    prefs.edit()
                        .putString("profile_config_$profileName", config)
                        .putStringSet("profile_names", existing)
                        .putString("active_profile", profileName)
                        .putString("wireguard_config", config)
                        .remove("config_error")
                        .apply()
                    recreate()
                }
            } catch (e: Exception) {
                prefs.edit().putString("config_error", e.message ?: "تعذر قراءة الملف").apply()
                recreate()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        migrateLegacyProfile()
        usageAccessState = hasUsageAccess()
        setContent {
            MaterialTheme {
                AutoVpnScreen(
                    usageGranted = usageAccessState,
                    configLoaded = !prefs.getString("wireguard_config", null).isNullOrBlank(),
                    profileNames = prefs.getStringSet("profile_names", emptySet()).orEmpty().toList().sorted(),
                    activeProfileName = prefs.getString("active_profile", "") ?: "",
                    onSelectProfile = { name ->
                        val config = prefs.getString("profile_config_$name", null)
                        if (!config.isNullOrBlank()) prefs.edit()
                            .putString("active_profile", name)
                            .putString("wireguard_config", config)
                            .apply()
                    },
                    configError = prefs.getString("config_error", null),
                    initialStatus = prefs.getString("service_status", "المراقبة غير مفعّلة") ?: "المراقبة غير مفعّلة",
                    readStatus = { prefs.getString("service_status", "المراقبة غير مفعّلة") ?: "المراقبة غير مفعّلة" },
                    onRequestUsage = { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
                    onPickConfig = { configPicker.launch(arrayOf("text/plain", "application/octet-stream", "*/*")) },
                    onStartMonitor = { requestVpnAndStart() },
                    onStopMonitor = { stopService(Intent(this, AppMonitorService::class.java)) },
                    loadApps = { loadLaunchableApps() },
                    savedPackages = prefs.getStringSet("selected_packages", emptySet()) ?: emptySet(),
                    onSaveSelection = { packages -> prefs.edit().putStringSet("selected_packages", packages.toSet()).apply() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        usageAccessState = hasUsageAccess()
    }

    private fun migrateLegacyProfile() {
        val names = prefs.getStringSet("profile_names", emptySet()).orEmpty()
        val legacyConfig = prefs.getString("wireguard_config", null)
        if (names.isEmpty() && !legacyConfig.isNullOrBlank()) {
            prefs.edit()
                .putString("profile_config_الخادم الحالي", legacyConfig)
                .putStringSet("profile_names", setOf("الخادم الحالي"))
                .putString("active_profile", "الخادم الحالي")
                .apply()
        }
    }

    private fun queryDisplayName(uri: android.net.Uri): String {
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
            }.orEmpty()
        }.getOrDefault("")
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun loadLaunchableApps(): List<InstalledApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0).mapNotNull { ri ->
            val ai = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
            if (ai.packageName == packageName) return@mapNotNull null
            InstalledApp(ri.loadLabel(packageManager).toString(), ai.packageName, ri.loadIcon(packageManager))
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    private fun requestVpnAndStart() {
        if (!hasUsageAccess()) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        val config = prefs.getString("wireguard_config", null)
        if (config.isNullOrBlank()) return
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) {
            pendingStart = true
            vpnPermission.launch(permissionIntent)
        } else requestNotificationPermissionThenStart()
    }

    private fun requestNotificationPermissionThenStart() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startMonitorService()
        }
    }

    private fun startMonitorService() {
        ContextCompat.startForegroundService(this, Intent(this, AppMonitorService::class.java))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AutoVpnScreen(
    usageGranted: Boolean,
    configLoaded: Boolean,
    profileNames: List<String>,
    activeProfileName: String,
    onSelectProfile: (String) -> Unit,
    configError: String?,
    initialStatus: String,
    readStatus: () -> String,
    onRequestUsage: () -> Unit,
    onPickConfig: () -> Unit,
    onStartMonitor: () -> Unit,
    onStopMonitor: () -> Unit,
    loadApps: suspend () -> List<InstalledApp>,
    savedPackages: Set<String>,
    onSaveSelection: (Set<String>) -> Unit
) {
    var apps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var selected by remember { mutableStateOf(savedPackages) }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf(initialStatus) }
    var profileMenuExpanded by remember { mutableStateOf(false) }
    var activeProfile by remember(activeProfileName) { mutableStateOf(activeProfileName) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps() }
        loading = false
        while (true) {
            status = readStatus()
            kotlinx.coroutines.delay(1000)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("AutoVPN") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("تشغيل VPN تلقائياً", style = MaterialTheme.typography.titleMedium)
                    Text("الحالة: $status", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                    Text("سيعمل النفق للتطبيقات التي تختارها فقط، أما بقية الهاتف فستستخدم الإنترنت العادي.", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(if (configLoaded) "ملف WireGuard: تم تحميله" else "ملف WireGuard: غير مضاف", color = if (configLoaded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
            }
            if (profileNames.isNotEmpty()) {
                ExposedDropdownMenuBox(
                    expanded = profileMenuExpanded,
                    onExpandedChange = { profileMenuExpanded = !profileMenuExpanded }
                ) {
                    OutlinedTextField(
                        value = activeProfile.ifBlank { "اختر خادماً" },
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("ملف الخادم النشط") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = profileMenuExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = profileMenuExpanded,
                        onDismissRequest = { profileMenuExpanded = false }
                    ) {
                        profileNames.forEach { name ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                onClick = {
                                    activeProfile = name
                                    profileMenuExpanded = false
                                    onSelectProfile(name)
                                }
                            )
                        }
                    }
                }
            }
            OutlinedButton(onClick = onPickConfig, modifier = Modifier.fillMaxWidth()) {
                Text("إضافة ملف خادم WireGuard (.conf)")
            }
            if (configError != null) Text("خطأ في الملف: $configError", color = MaterialTheme.colorScheme.error)
            if (!usageGranted) {
                Text("يلزم منح صلاحية الوصول إلى إحصائيات الاستخدام لاكتشاف التطبيق المفتوح.")
                Button(onClick = onRequestUsage, modifier = Modifier.fillMaxWidth()) { Text("منح صلاحية مراقبة التطبيقات") }
            } else Text("صلاحية مراقبة التطبيقات: مفعّلة", color = MaterialTheme.colorScheme.primary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("التطبيقات التي تستخدم VPN", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f)); Text("${selected.size} محدد")
            }
            if (loading) CircularProgressIndicator() else LazyColumn(Modifier.weight(1f)) {
                items(apps, key = { it.packageName }) { app ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(app.label)
                            Text(app.packageName, style = MaterialTheme.typography.labelSmall)
                        }
                        Checkbox(checked = app.packageName in selected, onCheckedChange = { checked ->
                            selected = if (checked) selected + app.packageName else selected - app.packageName
                            onSaveSelection(selected)
                        })
                    }
                    HorizontalDivider()
                }
            }
            Button(onClick = onStartMonitor, enabled = usageGranted && configLoaded && selected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                Text("بدء التشغيل التلقائي")
            }
            OutlinedButton(onClick = onStopMonitor, modifier = Modifier.fillMaxWidth()) { Text("إيقاف VPN والمراقبة") }
            Text("يمكنك إضافة أكثر من ملف خادم والتبديل بينها يدوياً. لا يختبر التطبيق السرعة تلقائياً بعد.", style = MaterialTheme.typography.labelSmall)
            Text("يجب أن يحتوي كل ملف على بيانات خادم WireGuard صحيحة وفعّالة.", style = MaterialTheme.typography.labelSmall)
        }
    }
}
